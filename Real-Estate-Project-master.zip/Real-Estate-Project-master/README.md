# Real-Estate-Project

Use Vite For better performance and get away from downloading multiple Libraries
